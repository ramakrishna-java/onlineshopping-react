import React from 'react'
import AllProductsPage from './components/AllProductsPage.jsx'

export default class App extends React.Component {
    render(){
        return(<>
        <AllProductsPage ></AllProductsPage>
        </>)
    }
}