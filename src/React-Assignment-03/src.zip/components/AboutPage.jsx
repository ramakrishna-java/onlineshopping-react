import React from 'react'

const AboutPage = () => {
  return (
    <div>
      <h2>About: This application provides information about the products</h2>
    </div>
  )
}

export default AboutPage
